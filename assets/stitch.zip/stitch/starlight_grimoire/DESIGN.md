# Design System Document: A Celestial Narrative

## 1. Overview & Creative North Star
The core objective of this design system is to transport the user from the frantic energy of the day into a serene, magical twilight. We call our Creative North Star **"The Celestial Storybook."**

Unlike traditional productivity apps that rely on rigid grids and sharp borders, this system embraces a "high-end editorial" feel. We break the template by using intentional asymmetry, organic roundedness, and a sense of infinite depth. We avoid "standard" layouts in favor of a layered, immersive experience where elements feel like they are floating in a midnight sky. Every interaction should feel soft, intentional, and quiet—mimicking the gentle turn of a page or the flicker of a distant star.

---

## 2. Colors & Atmospheric Depth
Our palette is rooted in the transition from dusk to deep night, accented by the warm glow of candlelight.

### The Palette
- **Primary (`#f8bd2a`):** Our "Star-glow" Gold. Used sparingly for critical CTAs and active states.
- **Background (`#111129`):** The "Midnight Void." A deep, desaturated blue that serves as the canvas for all elements.
- **Secondary (`#d1bcff`):** "Ethereal Lavender." Used for subtle highlights and secondary interactive elements.
- **Tertiary (`#bdc2ff`):** "Cloud-mist." Provides a soft contrast against the deep blues.

### The "No-Line" Rule
Standard 1px borders are strictly prohibited for sectioning. We define space through **Tonal Transitions**. Use the `surface-container` tiers to define boundaries. A card should be recognized not by its outline, but because it is a `surface-container-high` element resting on a `surface` background.

### Surface Hierarchy & Nesting
Treat the UI as physical layers of frosted material.
- **Base Level:** `surface` (`#111129`)
- **Primary Containers:** `surface-container` (`#1d1d36`) for main content areas.
- **Interactive Layers:** `surface-container-high` (`#282841`) for cards and inputs.
- **Elevated Floating Elements:** `surface-bright` (`#373751`) for elements that require immediate attention.

### Signature Textures: The "Glass & Gradient" Rule
To achieve a premium feel, avoid flat colors for primary actions. Use a subtle linear gradient from `primary` (`#f8bd2a`) to `primary_container` (`#3d2b00`) for main buttons. For overlays, apply a `backdrop-blur` of 12px-20px combined with a semi-transparent `surface-variant` to create a "Cloud Glass" effect.

---

## 3. Typography: The Editorial Voice
We utilize a high-contrast typographic pairing to balance modern readability with classical storytelling.

- **Display & Headlines (Noto Serif):** This is our "Narrator" font. It conveys authority and timelessness. Use `display-lg` (3.5rem) for hero moments and `headline-md` (1.75rem) for section titles.
- **Body & Labels (Plus Jakarta Sans):** Our "Guide" font. Chosen for its modern, geometric clarity and high legibility at small sizes. 
- **The Hierarchy:** Large, serif headlines should always be paired with generous letter-spacing in the `label` categories to create a sophisticated, breathable layout. Avoid "crowding" text; the space between a headline and body should feel as expansive as a night sky.

---

## 4. Elevation & Depth
Depth is not a shadow; depth is a feeling of immersion.

### The Layering Principle
Stack containers to create natural focus. A `surface-container-low` section should house `surface-container-highest` cards. This creates a "soft lift" that guides the eye without visual noise.

### Ambient Shadows
When a floating effect is required (e.g., a "Create Story" fab), use an **Ambient Glow** rather than a drop shadow.
- **Shadow Color:** A 10% opacity version of `surface_tint` (`#f8bd2a`).
- **Properties:** 0px Y-offset, 24px Blur, 0px Spread. This mimics the soft dispersion of light from a lantern.

### The "Ghost Border" Fallback
If accessibility requires a container boundary, use a "Ghost Border": `outline-variant` (`#47464d`) at **15% opacity**. Never use 100% opaque lines.

---

## 5. Components

### Buttons: The "Glowing Ember"
- **Primary:** Rounded `full` (9999px). Background is a gold gradient. Text is `on_primary_fixed` (`#261a00`). Add a 4px outer glow of `primary` when hovered.
- **Secondary:** `surface-container-highest` background with `primary` text. No border.

### Selection Chips: "Starlight Selectors"
- **Unselected:** `surface-container-high` background, `on_surface_variant` text.
- **Selected:** `secondary_container` background with a soft `secondary` glow.
- **Shape:** `sm` (0.5rem) or `md` (1.5rem) roundedness to keep the feel organic.

### Form Elements: "Celestial Inputs"
- **Dropdowns & Inputs:** Use `surface-container-highest`. Replace the standard bottom-line with a subtle background shift.
- **Sliders:** The track should be `surface-variant`. The "thumb" (handle) must be a `primary` gold circle that appears to glow, leaving a faint trail of the `primary` color behind it.

### Cards: "The Story Canvas"
- **Style:** Use `xl` (3rem) rounded corners for a soft, pillowy appearance.
- **Content:** No dividers. Use **vertical white space** (24px to 32px) to separate the title, metadata, and body text.
- **Layout:** Encourage asymmetrical content placement—for example, an icon floating in the top-right "sky" of a card while the text is anchored in the bottom-left.

---

## 6. Do's and Don'ts

### Do
- **Do** use `notoSerif` for all storytelling elements and `plusJakartaSans` for all functional elements.
- **Do** embrace "Breathable Layouts." If in doubt, add more margin.
- **Do** use `surface-container-lowest` to "push" content away, creating a sense of a deep horizon.
- **Do** ensure all interactive elements have a "glow" state rather than a "darken" state.

### Don't
- **Don't** use pure black (`#000000`) or pure white (`#ffffff`). Use the tokens provided to maintain the atmospheric "Midnight" tint.
- **Don't** use 1px solid borders. They break the immersion and make the app feel like a spreadsheet.
- **Don't** use sharp corners. The minimum roundedness for any card or container is `DEFAULT` (1rem).
- **Don't** use rapid, "snappy" animations. Transitions should be ease-in-out and slightly slower (300ms-500ms) to maintain the calming effect.